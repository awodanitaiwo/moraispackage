# moraispackage
this is a library that was created to create my own package on python

# How to install
...